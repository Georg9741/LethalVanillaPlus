## 2.6.1
- README updated

## 2.6.0
- [CORE Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusCORE/changelog/) _2.5.0 > 2.6.0_
- [FIXES Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.3.0 > 2.4.0_
- [HOST Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.3.0 > 2.3.1_

## 2.5.0
- [CORE Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusCORE/changelog/) _2.4.3 > 2.5.0_
- [FIXES Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.2.5 > 2.3.0_
- [HOST Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.2.2 > 2.3.0_

## 2.4.3
- [CORE Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusCORE/changelog/) _2.4.2 > 2.4.3_
- [FIXES Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.2.4 > 2.2.5_

## 2.4.2
- [CORE Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusCORE/changelog/) _2.4.1 > 2.4.2_
- [FIXES Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.2.3 > 2.2.4_
- _Version Text in Main Menu_
- _README Formatting_

## 2.4.1
- [CORE Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusCORE/changelog/) _2.4.0 > 2.4.1_
- [FIXES Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.2.2 > 2.2.3_
- [HOST Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusHOST/changelog/) _2.2.1 > 2.2.2_

## 2.4.0
- [CORE Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusCORE/changelog/) _2.3.1 > 2.4.0_
- [FIXES Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.2.1 > 2.2.2_
- [HOST Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusHOST/changelog/) _2.2.0 > 2.2.1_

## 2.3.1
- [CORE Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusCORE/changelog/) _2.3.0 > 2.3.1_
- [FIXES Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.2.0 > 2.2.1_

## 2.3.0
- [CORE Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusCORE/changelog/) _2.2.1 > 2.3.0_
- [FIXES Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.1.1 > 2.2.0_
- [HOST Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusHOST/changelog/) _2.1.0 > 2.2.0_

## 2.2.1
- [CORE Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusCORE/changelog/) _2.2.0 > 2.2.1_

## 2.2.0
- [CORE Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusCORE/changelog/) _2.1.0 > 2.2.0_
- [FIXES Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.1.0 > 2.1.1_

## 2.1.0
- [CORE Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusCORE/changelog/) _2.0.0 > 2.1.0_
- [FIXES Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusFIXES/changelog/) _2.0.0 > 2.1.0_
- [HOST Package](https://thunderstore.io/c/lethal-company/p/Georg9741/LethalVanillaPlusHOST/changelog/) _2.0.0 > 2.1.0_